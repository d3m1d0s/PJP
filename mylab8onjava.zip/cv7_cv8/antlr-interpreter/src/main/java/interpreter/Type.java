package interpreter;

public enum Type {
    INT, FLOAT, ERROR
}
